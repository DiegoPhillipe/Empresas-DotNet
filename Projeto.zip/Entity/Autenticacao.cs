﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Autenticacao
    {
        public Investor investor { get; set; }
        public Enterprise enterprise { get; set; }
        public bool success { get; set; }
    }
}

﻿using System;

namespace Entity
{
    public class RetornoEnterprise
    {
        public Enterprise enterprise { get; set; }
        public bool success { get; set; }
    }

    public class Enterprise
    {
        public int id { get; set; }
        public string enterprise_name { get; set; }

        public string email_enterprise { get; set; }
        public string facebook { get; set; }
        public string twitter { get; set; }
        public string linkedin { get; set; }
        public string phone { get; set; }
        public bool own_enterprise { get; set; }
        public string photo { get; set; }
        public double value { get; set; }
        public double shares { get; set; }
        public string city { get; set; }
        public string country { get; set; }
        public Enterprise_Type enterprise_type { get; set; }
    }
}

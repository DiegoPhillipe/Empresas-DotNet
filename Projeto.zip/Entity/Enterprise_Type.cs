﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Enterprise_Type
    {
        public int id { get; set; }
        public string enterprise_type_name { get; set; }
    }
}

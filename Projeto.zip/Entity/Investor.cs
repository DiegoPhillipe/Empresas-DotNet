﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Investor
    {
        public Investor()
        {
            portifolio = new Portifolio();
        }
        public int id { get; set; }
        public string investor_name { get; set; }
        public string email { get; set; }
        public string city { get; set; }
        public string county { get; set; }

        public double balance { get; set; }
        public string photo { get; set; }

        public Portifolio portifolio { get; set; }

        public double portfolio_value { get; set; }
        public bool first_access { get; set; }
        public bool super_angel { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Portifolio
    {
        public int enterprises_number { get; set; }

        public List<Enterprise> enterprises { get; set; }
    }
}

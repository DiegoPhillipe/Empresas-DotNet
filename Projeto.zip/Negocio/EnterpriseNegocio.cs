﻿using Entity;
using Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Negocio
{
    public class EnterpriseNegocio
    {
        public List<Enterprise> BuscarEmpresas()
        {
            try
            {
                EnterpriseRepositorio empresaRepositorio = new EnterpriseRepositorio();

                List<Enterprise> empresas = empresaRepositorio.BuscarEmpresas();

                return empresas;

            }
            catch (Exception)
            {
                throw;
            }
        }

        public Enterprise BuscarEmpresaPorId(int idEmpresa)
        {
            try
            {
                EnterpriseRepositorio empresaRepositorio = new EnterpriseRepositorio();

                List<Enterprise> empresas = empresaRepositorio.BuscarEmpresas();

                Enterprise empresa = null;

                if (empresas != null)
                {
                    empresa = empresas.Where(emp => emp.id == idEmpresa).FirstOrDefault();
                }

                return empresa;

            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Enterprise> BuscarEmpresasPorNomeETipo(string nomeEmpresa, string tipoEmpresa)
        {
            try
            {
                EnterpriseRepositorio empresaRepositorio = new EnterpriseRepositorio();

                List<Enterprise> empresas = empresaRepositorio.BuscarEmpresas();

                return empresas.Where(emp => emp.enterprise_name == nomeEmpresa && emp.enterprise_type.enterprise_type_name == tipoEmpresa).ToList();

            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

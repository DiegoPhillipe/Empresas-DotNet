﻿using Entity;
using Repositorio;
using System;
using System.Collections.Generic;
using System.Text;

namespace Negocio
{
    public class UserNegocio
    {
        public Autenticacao AutenticarUsuario(User usuario)
        {
            try
            {
                UserRepositorio usuarioRepositorio = new UserRepositorio();

                Investor user = usuarioRepositorio.BuscarUsuario(usuario.email, usuario.password);

                if (user == null)
                    return new Autenticacao() { success = false };
                else
                {
                    Autenticacao autenticacao = new Autenticacao();
                    autenticacao.investor = user;
                    autenticacao.success = true;

                    return autenticacao;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

﻿using Dapper;
using Entity;
using Persistencia.Interfaces;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Persistencia
{
    public class EnterpriseRepositorio : IEnterpriseRepositorio
    {
        private string connectionString;

        public EnterpriseRepositorio()
        {
            connectionString = @"Data Source=(local)\sqlexpress;Initial Catalog=Empresas;Persist Security Info=True;User ID=sa;Password=123456";
        }

        public List<Enterprise> BuscarEmpresas()
        {
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                return db.Query<Enterprise>("Select * From Enterprise").ToList();
            }

            return null;
        }
    }
}

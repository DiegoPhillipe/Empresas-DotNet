﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Persistencia.Interfaces
{
    public interface IEnterpriseRepositorio
    {
        public List<Enterprise> BuscarEmpresas();
    }
}

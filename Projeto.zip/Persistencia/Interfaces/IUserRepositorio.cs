﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositorio.Interfaces
{
    public interface IUserRepositorio
    {
        public Investor BuscarUsuario(string email, string senha);
    }
}

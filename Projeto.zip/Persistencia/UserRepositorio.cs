﻿using Dapper;
using Entity;
using Repositorio.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Repositorio
{
    public class UserRepositorio : IUserRepositorio
    {
        private string connectionString;

        public UserRepositorio()
        {
            connectionString = @"Data Source=(local)\sqlexpress;Initial Catalog=Empresas;Persist Security Info=True;User ID=sa;Password=123456";
        }


        public Investor BuscarUsuario(string email, string senha)
        {
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                return db.Query<Investor>(@"SELECT [id]
                                      ,[investor_name]
                                      ,[email]
                                      ,[senha]
                                      ,[city]
                                      ,[country]
                                      ,[balance]
                                      ,[photo]
                                      ,[portfolio_value]
                                      ,[first_acess]
                                      ,[super_angel]
                                  FROM[dbo].[usuario] Where email = '" + email + "' and senha = '" + senha + "'").FirstOrDefault();
            }
        }

    }
}

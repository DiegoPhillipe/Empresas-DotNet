﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Negocio;
using Persistencia;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/v1/enterprises")]
    public class EnterpriseController : ControllerBase
    {
        [Route(" ")]
        [HttpGet]
        public List<Enterprise> Get()
        {
            EnterpriseNegocio repositorio = new EnterpriseNegocio();

            return repositorio.BuscarEmpresas();
        }

        [Route("{idEmpresa}")]
        [HttpGet]
        public Enterprise Get(int idEmpresa)
        {
            EnterpriseNegocio repositorio = new EnterpriseNegocio();

            return repositorio.BuscarEmpresaPorId(idEmpresa);
        }

        [HttpGet]
        public List<Enterprise> Get(string name, string enterprise_types)
        {
            EnterpriseNegocio repositorio = new EnterpriseNegocio();

            return repositorio.BuscarEmpresasPorNomeETipo(name, enterprise_types);
        }
    }
}
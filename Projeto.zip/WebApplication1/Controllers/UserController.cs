﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Entity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Negocio;

namespace WebApplication1.Controllers
{
    [Route("api/v1/users")]
    [ApiController]
    public class UserController : ControllerBase
    {
        [HttpPost]
        [Route("auth/sign_in")]
        public Autenticacao Sign([FromBody] User usuario)
        {

            UserNegocio repositorio = new UserNegocio();

            Autenticacao autenticacao = repositorio.AutenticarUsuario(usuario);

            if (autenticacao.success == true)
            {
                Response.Headers.Add("access-token", "222222");
                Response.Headers.Add("client", "111111");
                Response.Headers.Add("uid", "333333");

            }

            return autenticacao;
        }
    }
}
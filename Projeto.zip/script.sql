CREATE DATABASE EMPRESAS
GO
USE EMPRESAS
GO
/****** Object:  Table [dbo].[Enterprise]    Script Date: 22/11/2019 10:20:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Enterprise](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[enterprise_name] [varchar](200) NOT NULL,
	[descricao] [varchar](max) NOT NULL,
	[email_enterprise] [varchar](50) NULL,
	[facebook] [varchar](50) NULL,
	[twitter] [varchar](50) NULL,
	[linkedin] [varchar](50) NULL,
	[phone] [varchar](15) NULL,
	[photo] [varchar](200) NULL,
	[value] [decimal](10, 2) NULL,
	[shares] [decimal](10, 2) NULL,
	[share_price] [decimal](10, 2) NULL,
	[own_shares] [decimal](10, 2) NULL,
	[city] [varchar](200) NULL,
	[country] [varchar](200) NULL,
	[id_enterprise_type] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Enterprise_Type]    Script Date: 22/11/2019 10:20:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Enterprise_Type](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[enterprise_type_name] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Usuario]    Script Date: 22/11/2019 10:20:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Usuario](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[investor_name] [varchar](100) NULL,
	[email] [varchar](100) NULL,
	[senha] [varchar](100) NULL,
	[city] [varchar](100) NULL,
	[country] [varchar](100) NULL,
	[balance] [decimal](10, 2) NULL,
	[photo] [varchar](255) NULL,
	[portfolio_value] [decimal](10, 2) NULL,
	[first_acess] [bit] NULL,
	[super_angel] [bit] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Enterprise]  WITH CHECK ADD FOREIGN KEY([id_enterprise_type])
REFERENCES [dbo].[Enterprise_Type] ([id])
GO
